import numpy as np

###############################################################################
# PART I DATA

exam_data = {
    'labels': ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'],

    'name': ['Amy', 'Dinesh', 'Kelly', 'Jenny', 'Vinod', 'Kevin',
             'Thor', 'Lisa', 'Kate', 'Simpson'],

    'score': [11.5, 7, 16.5, np.nan, 8, 21, 14.5, np.nan, 9, 18],

    'attempts': [3, 2, 1, 3, 2, 2, 13, 1, 1, 7]
}


browser_data = {
    'http_status': [301, 200, 404, 404, 200],
    'response_time': [1.00, 0.02, 0.08, 0.07, 0.04]
}


employee_data = {
    'Name': ['Dulkar', 'Lal', 'Abhi', 'Judy'],
    'Age': [34, 76, 68, 25],
    'Year of joining': ['02-06-2000', '26-03-1994', '18-11-2002', '06-02-2010']
}

###############################################################################
###############################################################################
# PART II DATA

sample_data = {

    'Origin': ['Oregon', 'Wyoming', 'Louisiana', 'Georgia', 'Arizona', 'California', 'Texas', 'Florida',

               'Maine', 'Iowa', 'Alaska', 'Washington'],

    'Regiment': ['Scouts', 'Scouts', 'Scouts', 'Scouts', 'Nighthawks', 'Nighthawks', 'Nighthawks',

                 'Nighthawks', 'Dragoons', 'Dragoons', 'Dragoons', 'Dragoons'],

    'Company': ['1st', '1st', '2nd', '2nd', '1st', '1st', '2nd', '2nd', '1st', '1st', '2nd', '2nd'],

    'Deaths': [62, 73, 37, 35, 523, 52, 25, 616, 43, 234, 523, 62],

    'Battles': [4, 7, 8, 9, 5, 42, 2, 2, 4, 7, 8, 3],

    'Size': [973, 1005, 1099, 1523, 1045, 957, 1099, 1400, 1592, 1006, 987, 849],

    'Veterans': [48, 435, 63, 345, 1, 5, 62, 26, 73, 37, 949, 48], 'Readiness': [2, 1, 2, 3, 1, 2, 3, 3, 2, 1, 2, 3],

    'Armored': [0, 0, 1, 1, 1, 0, 1, 1, 0, 1, 0, 1, ],

    'Deserters': [2, 3, 2, 3, 4, 24, 31, 2, 3, 4, 24, 31]
}
